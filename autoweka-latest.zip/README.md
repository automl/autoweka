[![Build Status](https://travis-ci.org/automl/autoweka.svg?branch=master)](https://travis-ci.org/automl/autoweka)

You can find the manual [here](http://www.cs.ubc.ca/labs/beta/Projects/autoweka/manual.pdf). Javadoc is available [here](https://automl.github.io/autoweka/).

This project will not be updated anymore. We may make exceptions for pull
requests.
